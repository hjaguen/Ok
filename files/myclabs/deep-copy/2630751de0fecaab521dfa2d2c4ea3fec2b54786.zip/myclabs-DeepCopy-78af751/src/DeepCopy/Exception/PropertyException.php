<?php declare(strict_types=1);

namespace DeepCopy\Exception;

use ReflectionException;

class PropertyException extends ReflectionException
{
}
