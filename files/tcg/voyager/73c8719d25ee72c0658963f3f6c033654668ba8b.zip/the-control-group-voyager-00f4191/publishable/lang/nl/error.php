<?php

return [
    'symlink_created_text'  => 'We hebben de missende symlink voor u aangemaakt.',
    'symlink_created_title' => 'Missende opslag symlink aangemaakt',
    'symlink_failed_text'   => 'Er trad een fout op bij het aanmaken van de missende symlink voor uw applicatie. '.
        'Het lijkt er op dat uw hosting provider deze actie niet ondersteund.',
    'symlink_failed_title'   => 'Missende opslag symlink kon niet worden aangemaakt',
    'symlink_missing_button' => 'Repareer het',
    'symlink_missing_text'   => 'We konden geen opslag symlink vinden. Dit kan problemen veroorzaken bij het '.
        'laden van mediabestanden vanuit de browser.',
    'symlink_missing_title' => 'Missende opslag symlink',
];
