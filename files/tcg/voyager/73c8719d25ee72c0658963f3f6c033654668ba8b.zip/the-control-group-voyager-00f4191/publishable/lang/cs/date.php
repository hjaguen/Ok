<?php

return [
    'last_week' => 'Minulý týden',
    'last_year' => 'Minulý rok',
    'this_week' => 'Tento týden',
    'this_year' => 'Tento rok',
];
