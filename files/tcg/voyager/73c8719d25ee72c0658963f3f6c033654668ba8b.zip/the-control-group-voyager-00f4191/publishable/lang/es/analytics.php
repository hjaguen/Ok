<?php

return [
    'by_pageview'            => 'Por página',
    'by_sessions'            => 'Por sesiones',
    'by_users'               => 'Por usuarios',
    'no_client_id'           => 'Para ver los análisis, necesitará obtener una ID de cliente de Google Analytics y añadirla a su configuración para la clave <code>google_analytics_client_id</code>. Obtenga su clave en la consola de desarrolladores de Google: ',
    'set_view'               => 'Seleccionar una vista',
    'this_vs_last_week'      => 'Esta semana vs la semana pasada',
    'this_vs_last_year'      => 'Este Año vs el Año pasado',
    'top_browsers'           => 'Principales Navegadores',
    'top_countries'          => 'Principales países',
    'various_visualizations' => 'Varias visualizaciones',
];
