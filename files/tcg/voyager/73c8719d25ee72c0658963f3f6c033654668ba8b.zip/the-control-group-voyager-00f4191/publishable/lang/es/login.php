<?php

return [
    'loggingin'    => 'Iniciando sesión',
    'signin_below' => 'Ingresar abajo:',
    'welcome'      => 'Bienvenido a Voyager. El administrador desaparecido de Laravel ',
];
