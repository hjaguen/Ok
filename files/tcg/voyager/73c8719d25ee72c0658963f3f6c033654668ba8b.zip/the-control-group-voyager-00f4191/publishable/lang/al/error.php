<?php

return [
    'symlink_created_text'  => 'Ne sapo krijuam linkun që mungon për ju.',
    'symlink_created_title' => 'Sjellja e humbur e ruajtjes u krijua',
    'symlink_failed_text'   => 'Ne nuk arritëm të gjeneronim simbolin e humbur për aplikacionin tënd.'
    .' Duket se ofruesi juaj i pritjes nuk e mbështet atë.',
    'symlink_failed_title'   => 'Nuk mundi të krijoj simbolin e ruajtjes së mungesës',
    'symlink_missing_button' => 'Fix it',
    'symlink_missing_text'   => 'Ne nuk mund të gjejmë një symlink të ruajtjes. '
    .'Kjo mund të shkaktojë probleme me ngarkimi i skedarëve të medias nga shfletuesi.',
                                'loading media files from the browser.',
    'symlink_missing_title' => 'Skeda e munguar e ruajtjes',
];
