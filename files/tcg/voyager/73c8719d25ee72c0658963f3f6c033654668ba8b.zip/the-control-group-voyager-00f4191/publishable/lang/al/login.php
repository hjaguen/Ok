<?php

return [
    'loggingin'    => 'Identifikimi',
    'signin_below' => 'Hyni më poshtë:',
    'welcome'      => 'Mirë se vini në Voyager. Adminja e zhdukur për Laravel ',
];
