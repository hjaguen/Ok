<?php

return [
    'field_password_keep'          => 'Թողնել դատարկ, որպեսզի պահպանեք նույնը',
    'field_select_dd_relationship' => 'Համոզվեք, որ դուք հաստատել եք համապատասխան հարաբերություն :class դասի :method մեթոդում',
    'type_checkbox'                => 'Նշատուփ',
    'type_codeeditor'              => 'Կոդի խմբագիր',
    'type_file'                    => 'Ֆայլ',
    'type_image'                   => 'Նկար',
    'type_radiobutton'             => 'Ռադիո կոճակ',
    'type_richtextbox'             => 'Տեքստային հարուստ խմբագիր',
    'type_selectdropdown'          => 'Ցանկից ընտրովի',
    'type_textarea'                => 'Տեքստային տարածք',
    'type_textbox'                 => 'Տեքստային տուփ',
];
