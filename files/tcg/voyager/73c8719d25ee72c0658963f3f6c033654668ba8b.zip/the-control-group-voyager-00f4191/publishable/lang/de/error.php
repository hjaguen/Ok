<?php

return [
    'symlink_created_text'   => 'Wir haben soeben den fehlenden Symlink für Sie angelegt.',
    'symlink_created_title'  => 'Fehlender Storage Symlink angelegt',
    'symlink_failed_text'    => 'Fehlender Symlink für Ihre Anwendung konnte nicht angelegt werden. Es scheint so als würde Ihr Hosting Provider dies nicht anbieten.',
    'symlink_failed_title'   => 'Fehlender Storage Symlink konnte nicht angelegt werden',
    'symlink_missing_button' => 'Bereinigen',
    'symlink_missing_text'   => 'Wir konnten keinen Storage Symlink finden. Dies könnte zu Problemen führen beim Laden von Medien Dateien aus dem Browser.',
    'symlink_missing_title'  => 'Fehlender Storage Symlink',
];
