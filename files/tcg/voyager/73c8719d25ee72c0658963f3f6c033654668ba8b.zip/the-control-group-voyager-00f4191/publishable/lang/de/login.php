<?php

return [
    'loggingin'    => 'Einloggen',
    'signin_below' => 'Unten anmelden:',
    'welcome'      => 'Willkommen bei Voyager. Der fehlende Admin für Laravel',
];
