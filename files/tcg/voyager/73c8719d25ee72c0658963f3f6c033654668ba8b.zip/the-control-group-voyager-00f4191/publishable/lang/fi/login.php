<?php

return [
    'loggingin'    => 'Kirjaudutaan sisään',
    'signin_below' => 'Kirjaudu sisään:',
    'welcome'      => 'Tervetuloa Voyageriin. Tämä on se Laravelista puuttunut hallintapaneeli.',
];
