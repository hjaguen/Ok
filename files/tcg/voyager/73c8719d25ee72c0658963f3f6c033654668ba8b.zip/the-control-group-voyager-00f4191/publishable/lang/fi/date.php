<?php

return [
    'last_week' => 'Viime viikko',
    'last_year' => 'Viime vuosi',
    'this_week' => 'Tämä viikko',
    'this_year' => 'Tämä vuosi',
];
