<?php

return [
    'avatar'            => 'Avatar',
    'edit'              => 'Editar o meu perfil',
    'edit_user'         => 'Editar usuario',
    'password'          => 'Contrasinal',
    'password_hint'     => 'Deixar baleiro para manter o mesmo',
    'role'              => 'Rol',
    'roles'             => 'Roles',
    'role_default'      => 'Rol por defeecto',
    'roles_additional'  => 'Roles adiccionais',
    'user_role'         => 'Rol do usuario',
];
