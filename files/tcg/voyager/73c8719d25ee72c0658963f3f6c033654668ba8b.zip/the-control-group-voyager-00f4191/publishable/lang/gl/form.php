<?php

return [
    'field_password_keep'           => 'Deixar baleiro para mantener o mesmo',
    'field_select_dd_relationship'  => 'Asegúrese de configurar a relación apropiada no método :method da clase :class.',
    'type_checkbox'                 => 'Casilla de verificación',
    'type_codeeditor'               => 'Editor de código',
    'type_file'                     => 'Arquivo',
    'type_image'                    => 'Imaxe',
    'type_radiobutton'              => 'Botón de radio',
    'type_richtextbox'              => 'Caixa de texto enriquecido',
    'type_selectdropdown'           => 'Seleccionar despregable',
    'type_textarea'                 => 'Área de texto',
    'type_textbox'                  => 'Caixa de texto',
];
