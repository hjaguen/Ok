<?php

return [
    'loggingin'    => 'A iniciar sessão',
    'signin_below' => 'Iniciar sessão abaixo:',
    'welcome'      => 'Bem-vindo ao Voyager. O painel de administração que faltava ao Laravel',
];
