<?php

return [
    'invalid'           => 'Json غير صالح',
    'invalid_message'   => 'يبدو أنك عرضت بعض Json الغير صالحة.',
    'valid'             => 'Json صالح',
    'validation_errors' => 'أخطاء أثناء التحقق',
];
