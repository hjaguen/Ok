<?php

return [
    'page'           => 'Strona|Strony',
    'page_link_text' => 'Wyświetl wszystkie strony',
    'page_text'      => 'Masz :count :string w swojej bazie danych. Kliknij przycisk poniżej, by wyświetlić wszystkie strony.',
    'post'           => 'Wpis|Wpisy',
    'post_link_text' => 'Wyświetl wszystkie wpisy',
    'post_text'      => 'Masz :count :string w swojej bazie danych. Kliknij przycisk poniżej, by wyświetlić wszystkie wpisy.',
    'user'           => 'Użytkownik|Użytkownicy',
    'user_link_text' => 'Wyświetl wszystkich użytkowników',
    'user_text'      => 'Masz :count :string w swojej bazie danych. Kliknij przycisk poniżej, by wyświetlić wszystkich użytkowników.',
];
