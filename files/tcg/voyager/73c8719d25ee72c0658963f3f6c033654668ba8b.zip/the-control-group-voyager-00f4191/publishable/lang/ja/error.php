<?php

return [
    'symlink_created_text'   => '存在しないシンボリックリンクを作成しました。',
    'symlink_created_title'  => '存在しないストレージのシンボリックリンクが作成されました',
    'symlink_failed_text'    => '存在しないシンボリックリンクの変換に失敗しました。このホストではサポートされていないようです。',
    'symlink_failed_title'   => '存在しないストレージのシンボリックリンクが作成できませんでした',
    'symlink_missing_button' => '解決する',
    'symlink_missing_text'   => 'ストレージのシンボリックリンクが見つかりません。 ブラウザからメディアファイルを読み込む際に問題が発生する可能性があります。',
    'symlink_missing_title'  => '存在しないストレージのシンボリックリンク',
];
