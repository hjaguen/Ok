<?php

return [
    'avatar'           => 'Avatar',
    'edit'             => 'Editar o meu perfil',
    'edit_user'        => 'Editar Utilizador',
    'password'         => 'Senha',
    'password_hint'    => 'Deixar vazio para manter o valor atual',
    'role'             => 'Função',
    'roles'            => 'Funções',
    'role_default'     => 'Função Padrão',
    'roles_additional' => 'Funções Adicionais',
    'user_role'        => 'Função do Utilizador',
];
